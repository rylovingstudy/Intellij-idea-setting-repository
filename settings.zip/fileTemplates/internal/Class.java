#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @description: TODO 
 * @author ${USER}
 * @date ${DATE} ${TIME}
 * @version 1.0
 */
public class ${NAME} {
}
